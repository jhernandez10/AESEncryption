FIRSTNAME: Joseph;
LASTNAME: Hernandez;
UTEID: jh43967;
CSACCOUNT: joseph10;
EMAIL: j_hernandez10@utexas.edu;

I use Youngs' implementation of MixColumns
The program overall is not very robust with only a few functions having some sort of check in place
The program can encode and decode correctly but it cannot read in a file to decrypt correctly so it cannot
write a decrypted version to a file correctly.

Generally the encryption is about as fast as the decryption in terms of speed.